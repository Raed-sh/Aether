import { FC } from "react"

export const Loader:FC = () => {
    return(
        <div>
            Loading...
        </div>
    )
}