import { FC } from "react"

export const Footer:FC = () => {
    return(
        <div className="ftr">
            <img src={""}/>
            <p>©Aetherlabs Inc 2022. All rights reserved.</p>
        </div>
    )
}