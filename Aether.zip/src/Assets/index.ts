import qm from './icons/qm.svg';

import cost from './icons/cost.svg';
import ip from './icons/ip.svg';
import network from './icons/network.svg';
import secure from './icons/secure.svg';

import polygon from './icons/polygon.svg';
import ethereum from './icons/ethereum.svg';
import binance from './icons/binance.svg';
import avalanche from './icons/avalanche.svg';
import fantom from './icons/fantom.svg';
import cronos from './icons/cronos.svg';

import arrow from './icons/arrow.svg';
import act from './icons/act.svg';
import non_act from './icons/non_act.svg';

import metamask from './icons/metamask.png';
import walletconnect from './icons/walletconnect.png';



import discord from './icons/discord.svg';
import telegram from './icons/telegram.svg';
import twitter from './icons/twitter.svg';
import github from './icons/github.svg';





export const icons = {
    chains:{
        polygon,ethereum,binance,avalanche,fantom,cronos
    },
    socials:{
        discord, telegram,twitter, github
    },
    qm,cost,ip,network,secure,arrow,act,non_act,metamask, walletconnect
}