import Pages from './Pages';


function App() {
  return (
    <Pages/>
  );
}

export default App;
