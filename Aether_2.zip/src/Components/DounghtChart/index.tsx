import { FC } from "react";

export const DChart:FC = () => {
    return(
        <>
        </>
    )
}